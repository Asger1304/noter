'''
    REPEATING WORDS

    Input:

       A single line with at most 100 characters containing words separated by 
       a single space, each word consisting of lower case letters 'a'-'z'. 
       The input contains at least one word.

    Output:

       A single line with the same words, but where words repeated multiple times
       after each other are replaced by a single occurrence of the word.

    Example:

       Input:  this this line contains the the the same word word repeated multiple multiple times times times

       Output: this line contains the same word repeated multiple times
'''

i=input()
s=i.split()
out=[s[0]]
for g in range(1,len(s)):
    if s[g]!=s[g-1]:
        out.append(s[g])
   
for o in out:
    print(o,end=" ")
